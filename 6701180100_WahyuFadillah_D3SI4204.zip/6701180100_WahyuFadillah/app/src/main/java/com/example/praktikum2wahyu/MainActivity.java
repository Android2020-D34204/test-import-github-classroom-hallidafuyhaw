package com.example.praktikum2wahyu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText angka1, angka2, operasi;
    Button hitung;
    TextView hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        angka1 = findViewById(R.id.editTextTextPersonName2);
        angka2 = findViewById(R.id.editTextTextPersonName);
        operasi = findViewById(R.id.editTextTextPersonName3);
        hitung = findViewById(R.id.button);
        hasil = findViewById(R.id.textView4);

    }

    public void hitungAngka(View view) {
        int a1 = Integer.parseInt(angka1.getText().toString());
        int a2 = Integer.parseInt(angka2.getText().toString());
        String hitungAngka = operasi.getText().toString();

        switch (hitungAngka) {
            case "+":
                int hitung = a1 + a2;
                hasil.setText(String.valueOf(hitung));
                break;

            case "-":
                int hitung2 = a1 - a2;
                hasil.setText(String.valueOf(hitung2));
                break;

            case "*":
                int hitung3 = a1 * a2;
                hasil.setText(String.valueOf(hitung3));
                break;

            case "/":
                int hitung4 = a1 / a2;
                hasil.setText(String.valueOf(hitung4));
                break;

            default:
                hasil.setText("operasi aritmatika tidak sesuai");

        }


    }
}
